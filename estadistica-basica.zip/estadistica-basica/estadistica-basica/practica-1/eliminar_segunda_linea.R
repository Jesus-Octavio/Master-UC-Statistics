all_content <- readLines("N_seaice_extent_daily_v3.0.csv")

skip_second <- all_content[-2]

seaice <- read.csv(textConnection(skip_second))
