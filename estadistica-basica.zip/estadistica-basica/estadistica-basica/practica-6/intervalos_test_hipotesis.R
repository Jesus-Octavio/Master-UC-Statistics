#INTERVALOS DE CONFIANZA#
#########################
#########################

#Intervalo de confianza para una media de una poblaci�n normal#
###############################################################

#t.test(datos, conf.level=0.95)

#Ejemplo: alturas de 38 alumnos
datos <-scan("alturas_ejemplo.txt")


#Intervalo de confianza para la media 
#al nivel de confianza 99%

t.test(datos, conf.level=0.99)

#Intervalo de confianza al 99%: [176.14 181.60]



#TEST DE HIPOTESIS CON VALOR DE REFERENCIA#
###########################################
###########################################

#Test de hipotesis sobre una media de una poblaci�n normal#
###########################################################
###########################################################

#t.test(datos, mu=mu_0)

##NOTA: Usamos los mismos datos en cada ejemplo, pero se supone que corresponden a muestras de poblaci�n de personas que han consumido la sustancia correspondiente al ejemplo de cada apartado.

#Hipotesis alternativa bilateral  mu != mu_0
############################################
## Ejemplo: Explorar si el consumo durante la adolescencia de una sustancia que no se ha analizado aumenta o disminuye la altura

#1) Definimos hip�tesis y elegimos alpha=0.05
#H_0: mu  = 177
#H_1: mu != 177 

# 2) Calculamos valor-p
t.test(datos,mu=177)
#p-value = 0.07081

# 3)  valor-p > alpha => No rechazo H0

#Hipotesis alternativa unilateral  mu > mu_0
############################################
## Ejemplo: Estudiar si una determinada dosis de hormona de crecimiento es suficiente para aumentar la altura

#1) Definimos hip�tesis y elegimos alpha=0.05

#H_0: mu=177
#H_1: mu > 177 

#2) Calculamos valor-p
t.test(datos,mu=177,alternative="greater")
#p-value = 0.0354

#3) valor-p < alpha => Rechazo H0

#Hipotesis alternativa unilateral  mu < mu_0
############################################
##Ejemplo: Estudiar si fumar una determinada cantidad de tabaco en la adolescencia disminuye la altura de forma significativa

#1) Definimos hip�tesis y elegimos alpha=0.05
#H_0: mu=177
#H_1: mu < 177 

#2) Calculamos valor-p
t.test(datos,mu=177,alternative="less")
#p-value = 0.96

#3) valor-p > alpha => No rechazo H0


