
#COMPARACION DE MEDIAS ENTRE DOS GRUPOS#
########################################

#usamos estos datos como ejemplo en los siguientes comandos:
A<-c(145,149,130,162,165,160,141)
B<-c(133,144,140,150,143,146,138)


#COMPARACION DE MEDIAS  (TEST DE WELCH)

#H_0: medias iguales
#H_1: medias diferentes

t.test(A,B)


#COMPARACION DE MEDIAS PARA DATOS EMPAREJADOS

#H_0: medias iguales
#H_1: medias diferentes

t.test(A,B,paired=TRUE)


#TEST DE IGUALDAD DE VARIANZAS

#H_0: varianzas homogéneas
#H_1: varianzas no homogéneas

var.test(A,B)

#COMPARACION DE MEDIAS CON VARIANZAS IGUALES

#H_0: medias iguales
#H_1: medias diferentes


t.test(A,B,var.equal=TRUE)
